package dk.example.internet_connectivity_example;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import net.cachapa.expandablelayout.ExpandableLayout;

import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ProgressDialog progressDialog;
    private Context mContext;
    private ImageView imageMenu;
    private ExpandableLayout expandableLayout;
    private LinearLayout llCheckConnection;
    private LinearLayout llEnableContinuousMonitoring1;
    private TextView textEnableContinuousMonitoring2, textEnableContinuousMonitoring1, textWifiConnected, textMobileConnected, textVPNConnected;
    private TextView textConnectionType, textIsConnectionFast, textDownloadTimeMillis, textDownloadTimeSecs, textLinkSpeedBps, textLinkSpeedKbps, textLinkSpeedMbps, textTestFileDownloadSpeed, textTestFileSize;
    private HashMap<String, String> downloadResponseInfo;
    private CardView cardSpeedCalculationInfo;
    private boolean menuExpanded, continuousMonitoringEnabled;
    private CheckBox checkBox;
    private Handler handler;
    private Runnable runnable;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContext = this; // Get activity context

        imageMenu = findViewById(R.id.imageMenu);
        expandableLayout = findViewById(R.id.expandableLayout);
        llCheckConnection = findViewById(R.id.llCheckConnection);
        LinearLayout llEnableContinuousMonitoring2 = findViewById(R.id.llEnableContinuousMonitoring2);
        llEnableContinuousMonitoring1 = findViewById(R.id.llEnableContinuousMonitoring1);
        checkBox = findViewById(R.id.checkBox);
        cardSpeedCalculationInfo = findViewById(R.id.cardWifiNetworkCheck);
        textEnableContinuousMonitoring1 = findViewById(R.id.textEnableContinuousMonitoring1);
        textEnableContinuousMonitoring2 = findViewById(R.id.textEnableContinuousMonitoring2);
        textEnableContinuousMonitoring2.setText(mContext.getResources().getString(R.string.action_enable_continuous_monitoring));
        textWifiConnected = findViewById(R.id.textWifiConnected);
        textMobileConnected = findViewById(R.id.textCellularConnected);
        textVPNConnected = findViewById(R.id.textVPNConnected);
        textConnectionType = findViewById(R.id.textConnectionType);
        textIsConnectionFast = findViewById(R.id.textIsConnectionFast);
        textDownloadTimeMillis = findViewById(R.id.textDownloadTimeMillis);
        textDownloadTimeSecs = findViewById(R.id.textDownloadTimeSecs);
        textLinkSpeedBps = findViewById(R.id.textNetworkSpeedBytes);
        textLinkSpeedKbps = findViewById(R.id.textNetworkSpeedKilobytes);
        textLinkSpeedMbps = findViewById(R.id.textNetworkSpeedMegabytes);
        textTestFileDownloadSpeed = findViewById(R.id.textDownloadSpeed);
        textTestFileSize = findViewById(R.id.textTestFileSize);

        switchViews(); //

        //noinspection deprecation
        handler = new Handler();
        final boolean[] isWifiOrVPN = new boolean[1];
        runnable = () -> {
            if (continuousMonitoringEnabled) {
                hideProgressDialog(); // Hide progress dialog if showing
                HashMap<String, String> data = new HashMap<>();
                if (InternetConnectivity.isConnectedToWifiNetwork(mContext)) {
                    data = InternetConnectivity.getWiFiConnectionSpeedInfo(mContext);
                    isWifiOrVPN[0] = true;
                } else if (InternetConnectivity.isConnectedToVPNNetwork(mContext)) {
                    data = InternetConnectivity.getVPNConnectionSpeedInfo(mContext);
                    isWifiOrVPN[0] = true;
                } else if (InternetConnectivity.isConnectedToMobileNetwork(mContext)){
                    continuousMonitoringEnabled = false;
                }
                if (isWifiOrVPN[0]) {
                    if (data != null) {
                        enableContinuousNetworkMonitoring(true);
                        try {
                            setSpeedCalculationInfo(data);
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
        };

        // Progress Dialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(true);

        llCheckConnection.setOnClickListener(view -> {
            if (checkPermissions()){
                if (continuousMonitoringEnabled){
                    enableContinuousNetworkMonitoring(false);
                }
                fetchLoadNetworkResult();
            }
        });

        imageMenu.setOnClickListener(view -> {
            if (!menuExpanded){
                menuExpanded = true;
                expandMenu(true);
            } else {
                menuExpanded = false;
                expandMenu(false);
            }
        });

        llEnableContinuousMonitoring1.setOnClickListener(view -> {
            if (!continuousMonitoringEnabled){
                expandMenu(false);
                checkBox.setChecked(true);
            } else {
                expandMenu(false);
                checkBox.setChecked(false);
            }
        }); llEnableContinuousMonitoring2.setOnClickListener(view -> llEnableContinuousMonitoring1.performClick());

        checkBox.setOnCheckedChangeListener((compoundButton, checked) -> enableContinuousNetworkMonitoring(checked));
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("continuousMonitoringEnabled", continuousMonitoringEnabled);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        continuousMonitoringEnabled = savedInstanceState.getBoolean("continuousMonitoringEnabled");
    }

    @Override
    protected void onStart(){
        super.onStart();
        if (!continuousMonitoringEnabled) {
            if (checkPermissions()) fetchLoadNetworkResult();
        }
        switchViews();
    }

    @Override
    protected void onResume(){
        super.onResume();
        if (!continuousMonitoringEnabled) {
            if (checkPermissions()) fetchLoadNetworkResult();
        }
        switchViews();
    }

    @Override
    protected void onPause(){
        super.onPause();
    }

    @Override
    protected void onStop(){
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mContext = null;
        handler.removeCallbacks(runnable);
    }

    private void switchViews(){
        if (!continuousMonitoringEnabled) textEnableContinuousMonitoring1.setText(mContext.getResources().getString(R.string.action_enable_continuous_monitoring));
        else textEnableContinuousMonitoring1.setText(mContext.getResources().getString(R.string.action_disable_continuous_monitoring));
    }
    private void enableContinuousNetworkMonitoring(boolean enable){
        if (enable) {
            continuousMonitoringEnabled = true;
            llCheckConnection.setVisibility(View.GONE);
            textEnableContinuousMonitoring1.setText(mContext.getResources().getString(R.string.action_disable_continuous_monitoring));
            textEnableContinuousMonitoring2.setText(mContext.getResources().getString(R.string.action_disable_continuous_monitoring));

            progressDialog.setTitle(mContext.getResources().getString(R.string.msg_initiating_network));
            progressDialog.setMessage(mContext.getResources().getString(R.string.msg_initiating_network) + ".  Please wait!!");
            showProgressDialog();
            handler.postDelayed(runnable, 2000); // Start handler
        } else {
            continuousMonitoringEnabled = false;
            handler.removeCallbacks(runnable);
            llCheckConnection.setVisibility(View.VISIBLE);
            textEnableContinuousMonitoring1.setText(mContext.getResources().getString(R.string.action_enable_continuous_monitoring));
            textEnableContinuousMonitoring2.setText(mContext.getResources().getString(R.string.action_enable_continuous_monitoring));
            Toast.makeText(mContext, mContext.getResources().getString(R.string.msg_continuous_network_monitoring_disabled), Toast.LENGTH_SHORT).show();
        }
    }
    /**
     * Function to fetch check connection and calculate network speed
     */
    private void fetchLoadNetworkResult() {
        if (InternetConnectivity.isConnectedToWifiNetwork(mContext)){
            progressDialog.setTitle(mContext.getResources().getString(R.string.label_wifi_network));
            progressDialog.setMessage("Checking connection and calculating download speed. Please wait");
            showProgressDialog(); // Show progress dialog
            setWiFiConnectionInformation();
        } else if (InternetConnectivity.isConnectedToMobileNetwork(mContext)) {
            progressDialog.setTitle(mContext.getResources().getString(R.string.label_cellular_network));
            progressDialog.setMessage("Checking mobile connection. Please wait");
            showProgressDialog(); // Show progress dialog
            setMobileConnectionInformation(); // Set mobile data connection information
        } else if (InternetConnectivity.isConnectedToVPNNetwork(mContext)) {
            progressDialog.setTitle(mContext.getResources().getString(R.string.label_vpn_network));
            progressDialog.setMessage("Checking connection and calculating download speed. Please wait");
            showProgressDialog(); // Show progress dialog
            setVPNConnectionInformation(); // Set VPN connection information
        } else {
            setNoConnectionInformation(); // Set no connection information
        }
    }

    /**
     * Function to set WiFi connection information
     */
    private void setWiFiConnectionInformation(){
        textWifiConnected.setText(getResources().getString(R.string.label_connected).toUpperCase());
        textWifiConnected.setTextColor(mContext.getResources().getColor(R.color.colorRed));
        textWifiConnected.setTypeface(textWifiConnected.getTypeface(), Typeface.BOLD);
        textMobileConnected.setText(getResources().getString(R.string.error_not_connected));
        textVPNConnected.setText(getResources().getString(R.string.error_not_connected));
        textConnectionType.setText(mContext.getResources().getString(R.string.label_wifi_network).toUpperCase());
        textConnectionType.setTextColor(mContext.getResources().getColor(R.color.colorRed));
        textConnectionType.setTypeface(textWifiConnected.getTypeface(), Typeface.BOLD);
        new Thread(() -> downloadResponseInfo = InternetConnectivity.getWiFiConnectionSpeedInfo(mContext)).start();
        setSpeedCalculationInfo(downloadResponseInfo);
    }

    /**
     * Function to set mobile connection information
     */
    private void setMobileConnectionInformation(){
        textMobileConnected.setText(getResources().getString(R.string.label_connected).toUpperCase());
        textMobileConnected.setTextColor(mContext.getResources().getColor(R.color.colorRed));
        textMobileConnected.setTypeface(textWifiConnected.getTypeface(), Typeface.BOLD);
        textWifiConnected.setText(getResources().getString(R.string.error_not_connected));
        textVPNConnected.setText(getResources().getString(R.string.error_not_connected));
        textConnectionType.setText(mContext.getResources().getString(R.string.label_cellular_network).toUpperCase());
        textConnectionType.setTextColor(mContext.getResources().getColor(R.color.colorRed));
        textConnectionType.setTypeface(textWifiConnected.getTypeface(), Typeface.BOLD);
        if (InternetConnectivity.isConnectionFast(mContext)) textIsConnectionFast.setText(mContext.getResources().getString(R.string.boolean_true));
        else textIsConnectionFast.setText(mContext.getResources().getString(R.string.boolean_false));
        hideProgressDialog(); // Hide progress dialog
        cardSpeedCalculationInfo.setVisibility(View.GONE);
        llEnableContinuousMonitoring1.setVisibility(View.GONE);
        imageMenu.setVisibility(View.GONE);
    }

    /**
     * Function to set VPN connection information
     */
    private void setVPNConnectionInformation(){
        textVPNConnected.setText(getResources().getString(R.string.label_connected));
        textVPNConnected.setTextColor(mContext.getResources().getColor(R.color.colorRed));
        textVPNConnected.setTypeface(textWifiConnected.getTypeface(), Typeface.BOLD);
        textWifiConnected.setText(getResources().getString(R.string.error_not_connected).toUpperCase());
        textMobileConnected.setText(getResources().getString(R.string.error_not_connected));
        textConnectionType.setText(mContext.getResources().getString(R.string.label_vpn_network).toUpperCase());
        textConnectionType.setTextColor(mContext.getResources().getColor(R.color.colorRed));
        textConnectionType.setTypeface(textWifiConnected.getTypeface(), Typeface.BOLD);
        new Thread(() -> downloadResponseInfo = InternetConnectivity.getVPNConnectionSpeedInfo(mContext));
        setSpeedCalculationInfo(downloadResponseInfo);
    }

    /**
     * Function to set details on no connection
     */
    private void setNoConnectionInformation(){
        textWifiConnected.setText(getResources().getString(R.string.error_not_connected));
        textMobileConnected.setText(getResources().getString(R.string.error_not_connected));
        textVPNConnected.setText(getResources().getString(R.string.error_not_connected));
        textConnectionType.setText(mContext.getResources().getString(R.string.error_not_connected));
        textIsConnectionFast.setText(mContext.getResources().getString(R.string.error_not_connected));
        textDownloadTimeMillis.setText(mContext.getResources().getString(R.string.error_not_connected));
        textDownloadTimeSecs.setText(mContext.getResources().getString(R.string.error_not_connected));
        textLinkSpeedBps.setText(mContext.getResources().getString(R.string.error_not_connected));
        textLinkSpeedKbps.setText(mContext.getResources().getString(R.string.error_not_connected));
        textLinkSpeedMbps.setText(mContext.getResources().getString(R.string.error_not_connected));
        textTestFileDownloadSpeed.setText(mContext.getResources().getString(R.string.error_not_connected));
        textTestFileSize.setText(mContext.getResources().getString(R.string.error_cannot_link_to_file));
        Toast.makeText(mContext, mContext.getResources().getString(R.string.error_no_connection), Toast.LENGTH_SHORT).show();
    }

    /**
     * Function to set speed calculation information
     * @param connectionSpeedInfo - HashMap
     */
    private void setSpeedCalculationInfo(HashMap<String, String> connectionSpeedInfo){
        String timeTakenMillis, timeTakenSecs, linkSpeedBps, linkSpeedKbps, linkSpeedMbps, testFileDownloadSpeed, testFileSize;
        if (connectionSpeedInfo != null) {
            timeTakenMillis = connectionSpeedInfo.get("timeTakenMillis");
            timeTakenSecs = connectionSpeedInfo.get("timeTakenSecs");
            linkSpeedBps = connectionSpeedInfo.get("linkSpeedBps");
            linkSpeedKbps = connectionSpeedInfo.get("linkSpeedKbps");
            linkSpeedMbps = connectionSpeedInfo.get("linkSpeedMbps");
            testFileDownloadSpeed = connectionSpeedInfo.get("testFileDownloadSpeed");
            testFileSize = connectionSpeedInfo.get("testFileSize");
            boolean isFastNetwork = Boolean.parseBoolean(connectionSpeedInfo.get("isFastNetwork"));

            if (isFastNetwork) {
                textIsConnectionFast.setText(mContext.getResources().getString(R.string.boolean_true));
            } else {
                textIsConnectionFast.setText(mContext.getResources().getString(R.string.boolean_false));
            }

            cardSpeedCalculationInfo.setVisibility(View.VISIBLE);
            llEnableContinuousMonitoring1.setVisibility(View.VISIBLE);
            imageMenu.setVisibility(View.VISIBLE);

            textDownloadTimeMillis.setText(mContext.getResources().getString(R.string.placeholder_milliseconds, timeTakenMillis));
            textDownloadTimeSecs.setText(mContext.getResources().getString(R.string.placeholder_seconds, timeTakenSecs));
            textLinkSpeedBps.setText(mContext.getResources().getString(R.string.placeholder_bytes, linkSpeedBps));
            textLinkSpeedKbps.setText(mContext.getResources().getString(R.string.placeholder_kilobytes, linkSpeedKbps));
            textLinkSpeedMbps.setText(mContext.getResources().getString(R.string.placeholder_megabytes, linkSpeedMbps));
            textTestFileDownloadSpeed.setText(String.format("%s Kbps", testFileDownloadSpeed));
            textTestFileSize.setText(testFileSize);
        }
        hideProgressDialog();
    }

    /**
     * Function to perform some task
     */
    private boolean checkPermissions(){
        final boolean[] permitted = new boolean[1];
        Dexter.withActivity(this)
                .withPermissions(Manifest.permission.INTERNET, Manifest.permission.ACCESS_NETWORK_STATE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) permitted[0] = true;
                    }
                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();
        return permitted[0];
    }

    /**
     * Function to show a progress dialog
     */
    private void showProgressDialog(){
        if (!progressDialog.isShowing()){
            progressDialog.show();
        }
    }

    /**
     * Function to hide progress dialog
     */
    private void hideProgressDialog(){
        if (progressDialog.isShowing()){
            progressDialog.dismiss();
        }
    }

    /**
     * Function to expand and collapse expandable menu
     * @param expand - boolean
     */
    private void expandMenu(boolean expand){
        if (expand){
            switchViews();

            // Expand Expandable Layout
            expandableLayout.setDuration(1000);
            expandableLayout.expand(true);
            imageMenu.setImageResource(R.drawable.ic_baseline_menu_open_24_white);
        } else {
            // Collapse Expandable Layout
            imageMenu.setImageResource(R.drawable.ic_baseline_menu_24_white);
            expandableLayout.collapse();
        }
    }

}