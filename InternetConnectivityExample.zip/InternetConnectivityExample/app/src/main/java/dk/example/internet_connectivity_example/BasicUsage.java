package dk.example.internet_connectivity_example;

import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;


@SuppressWarnings({"UnusedAssignment", "unused", "RedundantSuppression"})
public class BasicUsage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_usage);

        Context mContext = this;
        HashMap<String, String> connectionSpeedInfo;

        // Check connectivity to either WiFi or mobile connection
        if (InternetConnectivity.isConnectedToAnyNetwork(mContext)) {
            // Run process requiring WiFi or mobile connection
            doSomething();

            // Check if connection is fast
            if (InternetConnectivity.isConnectionFast(mContext)) {
                // Run heavy request requiring strong network connection
                doSomething();
            }
        }

        // Check connectivity to mobile connection
        if (InternetConnectivity.isConnectedToMobileNetwork(mContext)) {
            // Run process on mobile network
            doSomething();

            // Check if connection is fast
            if (InternetConnectivity.isConnectionFast(mContext)) {
                // Run heavy request requiring strong network connection
                doSomething();
            }

            // Check mobile connection speed with subtype
            if (InternetConnectivity.isConnectionFast(ConnectivityManager.TYPE_MOBILE,
                    TelephonyManager.NETWORK_TYPE_UNKNOWN)) {
                // Throw UNKNOWN NETWORK exception
                doSomething();
            }
        }


        // Check connectivity to WiFi connection
        if (InternetConnectivity.isConnectedToWifiNetwork(mContext)) {
            // Run process on WiFi connection - e.g. Heavy downloads, updates etc
            doSomething();

            // Check if connection is fast
            if (InternetConnectivity.isConnectionFast(mContext)) {
                // Run heavy request requiring strong network connection
                doSomething();
            }


            // Check if connection is fast and return network information
            // Returns HashMap<String, String> with details (timeTakenMillis, timeTakenSecs,
            // linkSpeedBps, linkSpeedKbps, linkSpeedMbps, testFileDownloadSpeed, testFileSize)
            String timeTakenMillis, timeTakenSecs, linkSpeedBps, linkSpeedKbps, linkSpeedMbps,
                    testFileDownloadSpeed, testFileSize;
            boolean isFastNetwork;
            connectionSpeedInfo = InternetConnectivity.getWiFiConnectionSpeedInfo(mContext);
            timeTakenMillis = connectionSpeedInfo.get("timeTakenMillis");
            timeTakenSecs = connectionSpeedInfo.get("timeTakenSecs");
            linkSpeedBps = connectionSpeedInfo.get("linkSpeedBps");
            linkSpeedKbps = connectionSpeedInfo.get("linkSpeedKbps");
            linkSpeedMbps = connectionSpeedInfo.get("linkSpeedMbps");
            testFileDownloadSpeed = connectionSpeedInfo.get("testFileDownloadSpeed");
            testFileSize = connectionSpeedInfo.get("testFileSize");
            isFastNetwork = Boolean.parseBoolean(connectionSpeedInfo.get("isFastNetwork"));
        }


        // Check connectivity to VPN connection
        if (InternetConnectivity.isConnectedToVPNNetwork(mContext)) {
            // Run process on WiFi connection - e.g. Heavy downloads, updates etc
            doSomething();

            // Check if connection is fast
            if (InternetConnectivity.isConnectionFast(mContext)) {
                // Run heavy request requiring strong network connection
                doSomething();
            }

            // Check if connection is fast and return network information
            // Returns HashMap<String, String> with details (timeTakenMillis, timeTakenSecs,
            // linkSpeedBps, linkSpeedKbps, linkSpeedMbps, testFileDownloadSpeed, testFileSize)
            String timeTakenMillis, timeTakenSecs, linkSpeedBps, linkSpeedKbps, linkSpeedMbps,
                    testFileDownloadSpeed, testFileSize;
            boolean isFastNetwork;
            connectionSpeedInfo = InternetConnectivity.getVPNConnectionSpeedInfo(mContext);
            timeTakenMillis = connectionSpeedInfo.get("timeTakenMillis");
            timeTakenSecs = connectionSpeedInfo.get("timeTakenSecs");
            linkSpeedBps = connectionSpeedInfo.get("linkSpeedBps");
            linkSpeedKbps = connectionSpeedInfo.get("linkSpeedKbps");
            linkSpeedMbps = connectionSpeedInfo.get("linkSpeedMbps");
            testFileDownloadSpeed = connectionSpeedInfo.get("testFileDownloadSpeed");
            testFileSize = connectionSpeedInfo.get("testFileSize");
            isFastNetwork = Boolean.parseBoolean(connectionSpeedInfo.get("isFastNetwork"));
        }
    }

    /**
     * Function to perform some task
     */
    private void doSomething() {
        // Background request or some other code here
    }
}